# Welcome to the fragment-hotspot-maps wiki!


![fragment hotspots](http://fragment-hotspot-maps.ccdc.cam.ac.uk/static/cover_small.jpg)

***

## Current resources

To help you get started we have created some resources covering the main features of the package. 

Have a question or feedback? Contact us! (**fragment-hotspot-support@ccdc.cam.ac.uk**)

[Background](https://github.com/prcurran/fragment_hotspot_maps/wiki/1.-Background)

[Installation](https://github.com/prcurran/fragment_hotspot_maps/wiki/2.-Installation)

[API framework](https://github.com/prcurran/fragment_hotspot_maps/wiki/3.-API-framework)

[Getting started](https://github.com/prcurran/fragment_hotspot_maps/wiki/4.-Getting-started)

[Visualisation](https://github.com/prcurran/fragment_hotspot_maps/wiki/5.-Visualisation)

[Scoring](https://github.com/prcurran/fragment_hotspot_maps/wiki/6.-Scoring)

[Analysis](https://github.com/prcurran/fragment_hotspot_maps/wiki/7.-Analysis)

[Current projects](https://github.com/prcurran/fragment_hotspot_maps/wiki/8.-Current-projects)

***
