from ccdc.protein import Protein
import os
from os.path import join, basename, exists
from glob import glob
from hotspots.hotspot_calculation import Hotspots
from hotspots import hotspot_io
from ccdc.cavity import Cavity

def make_savedir(prot_name, tag):
	save_dir = join(os.getcwd(), "{}_{}".format(prot_name, tag))
	if not exists(save_dir):
		os.mkdir(save_dir)
	return save_dir

def calc_hotspot(path, prot_name):
	"""
	param: path str, path to prepared protein
	"""
	protein = Protein.from_file(path)
	h = Hotspots()
	cavities = Cavity.from_pdb_file(path)
	#settings for the hotspot calculation
	
	settings = h._Sampler().Settings()
	settings.nrotations = 3000
	apolar_translation_threshold = 15
	polar_translation_threshold = 15

	result = h.from_protein(protein=protein,
							charged_probes=False,
							probe_size=7,
							buriedness_method='ligsite',
							cavities=cavities,
							nprocesses=3,
							sampler_settings = settings)
	out = make_savedir(prot_name, basename(p).split(".")[0])
	with hotspot_io.HotspotWriter(out, visualisation="pymol", grid_extension=".ccp4", zip_results=True) as writer:
		writer.write(result)
	return result
	

	

# Note - these proteins have already been aligned and prepared.
prot1_name= "PAK1"
prot2_name ="PAK4"
prot1_paths = glob(join(os.getcwd(), prot1_name, "*.pdb"))
prot2_paths = glob(join(os.getcwd(), prot1_name, "*.pdb"))

# Calculate hotspots for the two proteins

prot1_res_list = [calc_hotspot(path, prot1_name) for path in prot1_paths]
prot2_res_list = [calc_hotspot(path, prot2_name) for path in prot2_paths]

# Calculate ensemble hotspots for the two proteins
ensemble_1 = prot1_res_list[0].from_grid_ensembles(prot_1_res_list, prot1_name)
#Save ensemble:
out1 = save_dir(prot1_name, "ensemble")
with hotspot_io.HotspotWriter(out1, visualisation="pymol", grid_extension=".ccp4", zip_results=True) as writer:
     writer.write(result)

ensemble_2 = prot2_res_list[0].from_grid_ensembles(prot_2_res_list, prot2_name)
#Save ensemble:
out2 = save_dir(prot1_name, "ensemble")
with hotspot_io.HotspotWriter(out2, visualisation="pymol", grid_extension=".ccp4", zip_results=True) as writer:
     writer.write(result)

# Get selectivity maps
sel_map_result = ensemble_1.get_selectivity_map(ensemble_2)
out_sel = save_dir(prot1_name, "_{}_select".format(prot2_name))
