Hotspots API
************
.. automodule:: fragment_hotspot_maps.fragment_hotspot_maps
   :members:

